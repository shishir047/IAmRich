//
//  ViewController.swift
//  I Am Rich
//
//  Created by Shishir on 12/10/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

